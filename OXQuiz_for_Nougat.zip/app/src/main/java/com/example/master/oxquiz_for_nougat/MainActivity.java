package com.example.master.oxquiz_for_nougat;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button btn_Quizstart, btn_O1, btn_X1, btn_Result, btn_Back;
    TableLayout btn_Table;
    TextView display_qz,disp_Qz,text_O1,text_X1;

    Button btn_qz[] = new Button[10];
    Integer btn_qz_Id[] = {R.id.btn_Q1, R.id.btn_Q2, R.id.btn_Q3, R.id.btn_Q4, R.id.btn_Q5, R.id.btn_Q6, R.id.btn_Q7, R.id.btn_Q8, R.id.btn_Q9, R.id.btn_Q10};


    TextView disp_qz[] = new TextView[10];
    Integer disp_qz_Id[] = {R.id.displayQuiz1, R.id.displayQuiz2, R.id.displayQuiz3, R.id.displayQuiz4, R.id.displayQuiz5, R.id.displayQuiz6, R.id.displayQuiz7, R.id.displayQuiz8, R.id.displayQuiz9, R.id.displayQuiz10};


    char[] ans_quiz = {'O','X', 'O', 'X', 'X', 'O', 'O', 'O', 'X', 'X'};


    char O_X_clicked;

    int right, fail;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        setTitle("OX 퀴즈!");


        btn_O1 = (Button) findViewById(R.id.btn_O);
        btn_X1 = (Button) findViewById(R.id.btn_X);

        btn_Result = (Button) findViewById(R.id.btn_result);
        btn_Quizstart = (Button) findViewById(R.id.btn_quizstart);
        btn_Back = (Button)findViewById(R.id.btn_back);

        btn_Table = (TableLayout) findViewById(R.id.btn_table);

        display_qz = (TextView)findViewById(R.id.displayQuiz);
        disp_Qz = (TextView) findViewById(R.id.displayQuiz);
        text_O1 = (TextView)findViewById(R.id.text_O);
        text_X1 =(TextView)findViewById(R.id.text_X);


        btn_Quizstart.setOnClickListener(new View.OnClickListener() { // 시작하기 버튼 눌렀을때 동작
            @Override
            public void onClick(View v) {
                /* 시작하기 버튼 눌렀을때 음악 재생.
            try {
                String url = "https://www.youtube.com/watch?v=BEpn7BMQ9Z8";
                MediaPlayer mPlayer = new MediaPlayer();
                mPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
                mPlayer.setDataSource(url);
                mPlayer.prepare();
                mPlayer.start();
            } catch (Exception e){
                e.printStackTrace();
                }*/


                btn_Quizstart.setVisibility(View.GONE);
                display_qz.setVisibility(View.VISIBLE);
                btn_Table.setVisibility(View.VISIBLE);

            }
        });

        btn_Result.setOnClickListener(new View.OnClickListener() { //결과보기 버튼 클릭 구성
            @Override
            public void onClick(View v) {

                btn_Result.setVisibility(View.GONE);

                text_O1.setText("정답 개수 : " + right + "개" );
                text_X1.setText("오답 개수 : " + fail + "개");
                text_O1.setVisibility(View.VISIBLE); // 정답 개수
                text_X1.setVisibility(View.VISIBLE); // 오답 개수

                setTitle("OX퀴즈 결과보기");
            }
        });

        for (int i = 0; i < btn_qz_Id.length; i++) { // 배열속 변수가 대입된 수 만큼 증감
            final int index;

            index = i;

            btn_qz[index] = (Button) findViewById(btn_qz_Id[index]); // 버튼 배열 선언
            disp_qz[index] = (TextView) findViewById(disp_qz_Id[index]); // 문제 배열 선언

            btn_qz[index].setOnClickListener(new View.OnClickListener() { // Q1~Q10 버튼을 눌렀을때 문제표시 및 O,X,결과보기 버튼 표시
                @Override
                public void onClick(View v) {

                    setTitle(index+1 + "번 문제");


                    disp_Qz.setVisibility(View.GONE);
                    btn_Quizstart.setVisibility(View.GONE);
                    btn_Table.setVisibility(View.GONE);
                    disp_qz[index].setVisibility(View.VISIBLE);
                    btn_O1.setVisibility(View.VISIBLE);
                    btn_X1.setVisibility(View.VISIBLE);
                    btn_Back.setVisibility(View.VISIBLE);

                    // 처음으로 버튼 구성
                    btn_Back.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            btn_Table.setVisibility(View.VISIBLE);
                            disp_Qz.setVisibility(View.VISIBLE);
                            disp_qz[index].setVisibility(View.GONE);
                            btn_O1.setVisibility(View.GONE);
                            btn_X1.setVisibility(View.GONE);
                            btn_Back.setVisibility(View.GONE);

                            if (index == 9){
                                btn_Table.setVisibility(View.GONE);
                                disp_Qz.setVisibility(View.GONE);
                                btn_Back.setVisibility(View.GONE);
                                btn_Result.setVisibility(View.VISIBLE);
                            }
                        }
                    });

                    //문제 1번에서 O또는 X버튼을 눌렀을때 정답을 누르면 정답입니다. 오답을 누르면 오답입니다. 표시
                    btn_O1.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {

                            O_X_clicked = 'O' ;
                            if (ans_quiz[index]  == O_X_clicked  ){
                                Toast.makeText(getApplicationContext(), "정답입니다.", Toast.LENGTH_SHORT).show();
                                right = right+1;
                            } else if (ans_quiz[index]  != O_X_clicked ){
                                Toast.makeText(getApplicationContext(), "오답입니다.", Toast.LENGTH_SHORT).show();
                                fail = fail+1;

                            }
                        }
                    });
                    //문제 1번에서 O또는 X버튼을 눌렀을때 정답을 누르면 정답입니다. 오답을 누르면 오답입니다. 표시
                    btn_X1.setOnClickListener(new View.OnClickListener() {
                        @Override
                        public void onClick(View v) {
                            O_X_clicked = 'X' ;
                            if (ans_quiz[index]  == O_X_clicked  ){
                                Toast.makeText(getApplicationContext(), "정답입니다.", Toast.LENGTH_SHORT).show();
                                right = right+1;
                            } else if (ans_quiz[index]  != O_X_clicked ){
                                Toast.makeText(getApplicationContext(), "오답입니다.", Toast.LENGTH_SHORT).show();
                                fail = fail+1;
                            }
                        }
                    });
                }
            });
        }
    }
}
